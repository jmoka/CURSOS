import Client from "./Client";

export default class Notify {

    constructor(private client: Client) {
        
    }

    send(): void {
        
    }

}