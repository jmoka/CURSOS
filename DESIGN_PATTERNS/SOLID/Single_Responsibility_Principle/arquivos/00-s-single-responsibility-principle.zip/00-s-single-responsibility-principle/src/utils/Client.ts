export default class Client {

    create(): void {

    }

    read(): void {

    }

    update(): void {

    }

    delete(): void {

    }

}
