export default interface IVehicleCar {

    configureVehicle(color: string, year: number, engine: number, seats: number, doors: number): void;
    startVehicle(): void;

}
