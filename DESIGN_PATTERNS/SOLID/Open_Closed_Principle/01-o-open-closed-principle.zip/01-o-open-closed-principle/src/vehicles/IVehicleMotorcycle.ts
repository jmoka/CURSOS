export default interface IVehicleMotorcycle {

    configureVehicle(color: string, year: number, engine: number): void
    startVehicle(): void;

}
