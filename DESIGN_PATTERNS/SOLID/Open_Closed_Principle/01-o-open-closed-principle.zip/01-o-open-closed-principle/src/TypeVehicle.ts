enum TypeVehicle {
    CAR,
    MOTORCYCLE
};

export default TypeVehicle;